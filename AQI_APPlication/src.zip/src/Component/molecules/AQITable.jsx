import React, { useState, useEffect } from "react";
// import Pre from "../molecules/Pre";
// import Circle from "../molecules/Circle";
// import Gases from "../molecules/Gases";

const SideCard = ({ location = "Mumbai", isDarkMode }) => {
  const [cityData, setCityData] = useState([]); // State to store the fetched city data
  // const [latestAQI, setLatestAQI] = useState("N/A"); // State to store the latest AQI value
  // const [isClicked, setIsClicked] = useState(false); // Track click state

  useEffect(() => {
    // Fetch city data from the backend
    const fetchData = async () => {
      try {
        const response = await fetch("http://192.168.165.5:8000/api/get-data/");
        if (!response.ok) throw new Error("Network response was not ok");
        const data = await response.json();
        // Get the AQI of the latest data entry
        const latestAQIValue = data.length > 0 ? data[data.length - 250].value : "N/A";
        setCityData(data);
        // setLatestAQI(latestAQIValue); // Set the latest AQI
      } catch (error) {
        console.error("Error fetching AQI data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="p-4">
    <h2 className="text-2xl font-bold mb-4">Pune City AQI and Gases Data (High to Low AQI)</h2>
    <table className="table-auto w-full border-collapse" aria-label="AQI and gas data for Pune localities">
      <thead>
        <tr className={`${isDarkMode ? 'bg-gray-500' : 'bg-gray-200'}`}>
          <th className="border px-4 py-2">Locality</th>
          <th className="border px-4 py-2">AQI</th>
          <th className="border px-4 py-2">SO₂ (µg/m³)</th>
          <th className="border px-4 py-2">CO (µg/m³)</th>
          <th className="border px-4 py-2">NO₂ (µg/m³)</th>
          <th className="border px-4 py-2">PM2.5 (µg/m³)</th>
          <th className="border px-4 py-2">PM10 (µg/m³)</th>
          <th className="border px-4 py-2">O₃ (µg/m³)</th>
        </tr>
      </thead>
      <tbody>
        {cityData.map((city, index) => (
          <tr key={index} className="text-center">
            <td className="border px-4 py-2">
              <Link to={`/locality/${city.locality}`} className="text-blue-500 hover:underline">
                {city.locality}
              </Link>
            </td>
            <td className="border px-4 py-2">{city.aqi}</td>
            <td className="border px-4 py-2">{city.so2}</td>
            <td className="border px-4 py-2">{city.co}</td>
            <td className="border px-4 py-2">{city.no2}</td>
            <td className="border px-4 py-2">{city.pm25}</td>
            <td className="border px-4 py-2">{city.pm10}</td>
            <td className="border px-4 py-2">{city.o3}</td>

          </tr>
        ))}
      </tbody>
    </table>
    {cityData}
  </div>
  );
};

export default SideCard;
